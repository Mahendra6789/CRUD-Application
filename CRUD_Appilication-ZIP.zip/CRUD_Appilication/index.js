const express = require('express');
const cors = require('cors');
require('./db/config');
const Product = require('./db/Product');
// const port= process.env.port || 3000;
const bodyParser = require('body-parser');
const { response } = require('express');
const app = express();

app.use(express());
app.use(cors());
app.set("view engine", "ejs");//To use Html and js file
app.use(express.static("Public"))//To use CSS 
app.use(bodyParser.urlencoded({ extended: false }))//body parser
app.use(bodyParser.json())//body application /json

app.get('/', (req, resp) => {
    resp.render("Home")
})
//create or insert data
app.post('/add', (req, resp) => {
    const ItemName = req.body.name;
    const Category = req.body.Category;
    const Price = req.body.Price;
    //    console.log(name,category,price)
    const product = new Product({
        ItemName,
        Category,
        Price
    })
    product.save(err => {
        if (err) {
            console.log("Error is:")
        } else {
            resp.redirect('/')
        }
    })
})

//Find data

app.get('/show', (req, resp) => {
    Product.find((err, result) => {
        if (err) throw err;
        resp.render('show',{
            Products : result
        })
    }
    )});

    //Update Data
    app.get("/edit/:id",(req,resp)=>{
        // console.log(req.params.id)
        Product.findOneAndUpdate({_id:req.params.id},req.body,{new:true},(err,result)=>{
            if(err){
                console.log("Cannot Update")
            }else{
                resp.render('edit',{ Products:result})
            }
        })
    })

    app.post("/edit/:id",(req,resp)=>{
        Product.findByIdAndUpdate({_id:req.params.id},req.body,(err,result)=>{
            if(err){
                console.log("error")
            }else{
                resp.redirect("/show")
            }
        })
    })
    // Delete Data

    app.get("/delete/:id",(req,resp)=>{
        Product.findByIdAndDelete({_id:req.params.id},req.body,(err,result)=>{
            if(err){
                console.log("Error")
            }else{
                console.log("Deleted")
                resp.redirect('/show')
            }
        })
    })

    app.listen(5000);