const mongoose = require('mongoose')

const productschema = new mongoose.Schema({
    ItemName: {
        type: String
    },
    Category: {
        type: String
    },
    Price: {
        type: Number
    },
})

module.exports = mongoose.model("Product", productschema)